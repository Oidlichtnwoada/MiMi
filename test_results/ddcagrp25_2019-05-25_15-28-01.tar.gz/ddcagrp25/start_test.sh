#synchronize repo
cd MiMi
git fetch
git pull
cd ..
#level0
rm -rf ./level0
mkdir level0
cd level0
mkdir src
cd .. 
cp -r ./MiMi/ca/src/* ./level0/src
#level1
rm -rf ./level1
mkdir level1
cd level1
mkdir src
cd ..
cp -r ./MiMi/ca/src/* ./level1/src
rm -rf TESTME*
touch TESTME

