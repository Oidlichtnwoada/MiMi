class InputAndOutputExpectedGenerator:
    def __init__(self):
        pass

    def generateInput(self, param1, param2, param3):
        return param3

    def generateOutputExpected(self, param1, param2):
        return param1
